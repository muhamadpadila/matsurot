package com.haeril.lail.data.rensponse

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseLogin(
    @field:SerializedName("username")
    var username: String? = null,
    // val = const(tidak bisa di ubah), var = let(bisa di ubah)
    @field:SerializedName("password")
    var password: String? = null
) : Parcelable
