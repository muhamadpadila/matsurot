package com.haeril.lail.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.haeril.lail.data.rensponse.DataItem
import com.haeril.lail.data.rensponse.ResponseDzikir
import com.haeril.lail.databinding.ItemDzkirBinding

class MorningAdapter(val listM: ArrayList<DataItem>): RecyclerView.Adapter<MorningAdapter.ListViewHolder>() {

    // menetukan view yang digunakan pada layout (item_dzikir.xml)
    class ListViewHolder(binding: ItemDzkirBinding): RecyclerView.ViewHolder(binding.root) {

        private val notes = binding.tvNotes
        private val title = binding.tvTitle
        private val fawaid = binding.tvFawaid
        private val source = binding.tvSource
        private val arabic = binding.tvArabic

        fun setData(listDzikir: DataItem) {
            notes.text = listDzikir.notes
            title.text = listDzikir.title
            fawaid.text = listDzikir.fawaid
            source.text = listDzikir.source
            arabic.text = listDzikir.arabic
        }
    }
    // untuk membuat lifecucle onCreate pada class kotlin
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val binding = ItemDzkirBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding)
    }
    // untuk menentukan jumlah data yang akan ditampilkan
    override fun getItemCount(): Int {
        return listM.size
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val data = listM[position]
        holder.setData(data)
    }
}